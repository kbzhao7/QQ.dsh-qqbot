# 参考用户的插件 · 1.0

DeepSeek Harness 的 QQ 群聊简约插件，基于原 smart.12 的收发流程制作。版本号为 `1.0.3`，管理界面显示实际版本号。

保留自然介入、工作区表情、识图、工作区文件操作、静默回复和可选联网搜索。插件自身注册三个模型工具：`qqbot_describe_image`、`qqbot_send_emoji`、`qqbot_skip_reply`。联网搜索复用 Harness 的 `web_search`，默认关闭，可在 UI 开启。没有主动日程、激活内主动分段工具、腾讯云审核、举报处罚、视频识别或永久记忆服务。

## 安装

在 DeepSeek Harness 目录的 Windows CMD 中运行，替换安装包路径：

```bat
pnpm dsh plugin --profile qqbot-ref1 add "D:\QClaw\dsh-qqbot-user-reference-1.0.3.tgz"
pnpm dsh --profile qqbot-ref1
```

请安装 **TGZ**。源码 ZIP 用于修改代码，不能直接交给 `plugin add`。先停止旧 QQ 插件进程；两个版本不能同时占用 `17880` 和 `18081`。

QQ 凭据未配置时按终端提示扫码绑定。也可在启动前设置自己的 `QQBOT_APPID` 和 `QQBOT_SECRET`。本包不含 AppID、AppSecret、任何模型密钥或管理 token。新安装默认 WebSocket，无需域名、证书或公网回调。QQ 开放平台必须支持并选择对应接入方式。UI 可切换 Webhook，保存后重启 dsh；Webhook 仍使用 `127.0.0.1:18081/qqbot/webhook`。非 @ 自然介入仍依赖平台的非 @ 消息推送权限。

复制启动日志中的完整“管理链接”（含 token），进入白色 UI。两段用户提供的提示依次确认，第二次确认后保存状态，此安装的后续启动不再弹出。

主聊天模型使用 **Harness 的模型与凭据配置**，需要自行配置。介入判断和识图 API 在本插件网页顶部的“API 设置”中填写，点击“保存 API”后自动保存到本机，无需先创建或编辑 TXT。联网搜索使用 Harness 的 DeepSeek 搜索凭据（`DEEPSEEK_API_KEY`），不读取这两个 TXT；仅按需调用，每次一个查询，默认单会话每分钟最多三次。

详细步骤与网页设置说明见 [使用说明](docs/reference-user-plugin-1.0-guide.md)。

## 1.0.3 更新

UI → 关键词与角色提示词 → 激活上限（秒），保存后生效，默认 600 秒。修复旧轮次计数耗尽时倒计时尚未结束却重新调用激活分类器的问题；现以倒计时决定活动状态。主模型的静默回复开关继续保留。

## 从旧插件切换

停止机器人后，可用下列命令卸载旧包（删除 `node_modules` 不会卸载它）：

```bat
pnpm dsh plugin --profile qqbot remove dsh-qqbot-smart-dialogue
```

如果继续使用旧 profile，检查其 `cordis.patch.yml` 中是否仍有旧 `im-qqbot` 插件的专用配置；不要把旧配置直接当作新插件配置使用。独立安装仍推荐上面的 `qqbot-ref1` profile。新插件日志会显示 `dsh-qqbot-user-reference` / “参考用户的插件”，不会从 `dsh-qqbot-smart-dialogue/src/index.ts` 启动。

## 本地开发

需要 Node.js 22.19+ 或 24+ 和 pnpm。安装源码依赖后：

```bat
pnpm install
pnpm build
pnpm test
node scripts/check-harness-tools.mjs "D:\QClaw\deepseek-harness"
```

最后一条用已安装依赖的 Harness 源码校验三个工具的 Schema、动态开关和系统提示词前缀。所有内置测试均使用临时目录与模拟 API，不消耗真实 API 余额。

上游收发基础来自 tencent-connect/dsh-qqbot，保留其 MIT 许可。此为用户定制版本。
